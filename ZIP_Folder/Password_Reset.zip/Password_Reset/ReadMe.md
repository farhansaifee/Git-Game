# Git game
## How to use the files
We have added a few files that only work properly via the web server and are intended for password reset via email. Since we don't have an email server locally, we uploaded them to a hosting website that provides us with an email server, as described in our documentation. 

In the script the passwords were taken out of the database, if you want to make the script work you have to add the files in to the "Include" folder and change the database interface Username, Password, Db-Name and the Hrefs of e.g. "Forgot Password".

Link to the website: https://git-game.000webhostapp.com

