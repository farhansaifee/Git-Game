-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 17. Jan 2022 um 19:37
-- Server-Version: 10.4.22-MariaDB
-- PHP-Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `gitgame`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `challenge`
--

CREATE TABLE `challenge` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `challenge`
--

INSERT INTO `challenge` (`id`, `name`) VALUES
(1, 'Challenge 1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `question` varchar(800) NOT NULL,
  `hint` varchar(800) NOT NULL,
  `solution` varchar(800) NOT NULL,
  `task_number` int(11) NOT NULL,
  `challenge_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `task`
--

INSERT INTO `task` (`id`, `question`, `hint`, `solution`, `task_number`, `challenge_id`) VALUES
(1, 'To check if GIT is installed there is a simple command to do that.', ' You should consider version command for this.', 'git --version', 1, 1),
(4, ' You have to connect to your Github Account, in order to upload changes in your repository. (Use name as your name and your.email.address@mail.com as email address)\r\n', 'There are 2 commands to do that', 'git config --global user.name \"Name\"#git config --global user.email your.email.address@mail.com', 2, 1),
(5, 'Create a new Repository in a new Folder (Folder name: newFolder)\r\n', 'Use the command \'mkdir <foldername>\' to create a new folder\r\nand then INITialize your repository.\r\n', 'mkdir newFolder#git init\r\n', 3, 1),
(6, ' Suppose there is already a file in your current folder. Now check the current status.\r\n', 'Add the 2 words together and type in the command\r\n', 'git status', 4, 1),
(7, ' Add all changes to the repository.\r\n', 'Use a \'.\' (dot) to complete the command\r\n', 'git add .\n', 5, 1),
(8, 'Commit your changes and add a message to it\r\n', 'Use \'-m\' to add a message', 'git commit -m \"<Message>\"', 6, 1),
(9, 'Now push your changes to your repository\r\n', 'There are just 2 words in this command\r\n', 'git push', 7, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `UserID` bigint(20) NOT NULL,
  `Gender` enum('male','female','none','') DEFAULT NULL,
  `Firstname` varchar(50) DEFAULT NULL,
  `Lastname` varchar(50) DEFAULT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Avatar` varchar(50) DEFAULT NULL,
  `RegisteredAt` datetime NOT NULL DEFAULT current_timestamp(),
  `LastLogin` datetime DEFAULT NULL,
  `Bio` text DEFAULT NULL,
  `Token` varchar(128) DEFAULT NULL,
  `Token2` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`UserID`, `Gender`, `Firstname`, `Lastname`, `Username`, `Email`, `Password`, `Avatar`, `RegisteredAt`, `LastLogin`, `Bio`, `Token`, `Token2`) VALUES
(1, 'female', 'Pavle', 'Tomanovic', 'Paka94', 'tomanovic.pavlee@gmail.com', '216afd3c01b2bb04649fadbe08a6d78fc651f9cace5a3f187aba8fbd2f045cb7', NULL, '2021-10-20 16:31:49', NULL, NULL, NULL, 'rAxKCfwu4Yps5Lq8'),
(2, 'male', 'Pavlee', 'Tomanovicc', 'Paki94', 'pakibulke@gmail.com', '5b5e03874f78ed61e9ed1e0071dc08e05ef6ca31017e718e464bd12bd4136e74', '71ZCJYuOqIL.png', '2021-11-18 09:08:23', NULL, NULL, 'dJs2n10LKT50s8Vo', 'L676SPsg00XG6YQr'),
(3, 'male', 'Pavle', 'Tomanovic', 'Pavlee', 'pakibulk1@gmail.com', '5b5e03874f78ed61e9ed1e0071dc08e05ef6ca31017e718e464bd12bd4136e74', NULL, '2021-11-25 13:58:13', NULL, NULL, NULL, 'Y0g2qJ2iYnoFgvqv'),
(4, 'male', 'Admin', 'Admin', 'admin123', 'admin@fmail.com', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', NULL, '2022-01-12 20:09:48', NULL, NULL, '2YO2193kAn1y28DR', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_challenge`
--

CREATE TABLE `user_challenge` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `challenge_id` int(11) NOT NULL,
  `last_done_task` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `user_challenge`
--

INSERT INTO `user_challenge` (`id`, `user_id`, `challenge_id`, `last_done_task`) VALUES
(1, 2, 1, 0);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `challenge`
--
ALTER TABLE `challenge`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indizes für die Tabelle `user_challenge`
--
ALTER TABLE `user_challenge`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `challenge`
--
ALTER TABLE `challenge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `UserID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `user_challenge`
--
ALTER TABLE `user_challenge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
