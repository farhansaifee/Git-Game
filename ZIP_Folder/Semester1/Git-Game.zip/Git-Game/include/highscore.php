<?php
$user = $db->getUser($_SESSION["user"]["ID"]);
?>
<div class="container">


</div>

<script src="js/dashboard.js"></script>