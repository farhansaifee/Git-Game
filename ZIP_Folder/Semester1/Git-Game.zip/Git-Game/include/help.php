<div class="container">
    <div class="card">
        <div class="card-body">
            <div>This page is here to help you get started with our site aswell as for you to get to know it better and get familiarized with it!</div>
            <br>
            <h3 id="faq">FAQ</h3>
            <br>
            <div>
            <form action="mailto:if20b150@technikum-wien.at" method="get" enctype="text/plain">
                <div class="form-group">
                    <label for="exampleFormControlInput1">Email address: </label>
                    <input type="email" class="form-control" id="helpEmail" placeholder="name@example.com">
                </div>
                <div class="form-group">
                    <label for="helpFirstName">First name: </label>
                    <input type="text" class="form-control" id="helpFirstName" placeholder="Arthur">
                </div>
                <div class="form-group">
                    <label for="helpLastName">Last name: </label>
                    <input type="text" class="form-control" id="helpLastName" placeholder="Morgan">
                </div>
                <div class="form-group">
                    <label for="helpComment">Comment: </label>
                    <textarea class="form-control" id="helpComment" rows="3" placeholder="Here you can express your regards and concerns!"></textarea>
                </div>
                <button type="submit" class="btn btn-primary" id="helpSubmit">Submit</button>
            </form>
            </div>


        </div>
    </div>
</div>