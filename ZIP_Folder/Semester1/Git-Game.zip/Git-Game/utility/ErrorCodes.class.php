<?php

abstract class ErrorCodes
{
    const NoContent = 1;
    const OK = 0;
    const Unauthorized = -1;
    const SQLError = -2;
    const BadInput = -3;
}