# Git-Game
This is a Github Repository for our UAS Technikum Wien project. Our goal is to create an educational browsergame about learning "GIT".
